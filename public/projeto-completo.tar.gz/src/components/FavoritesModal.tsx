import React, { useState, useEffect } from 'react';
import {
  X,
  Star,
  Bus,
  Train,
  Ship,
  Trash2,
  ExternalLink,
  MapPin,
  Check,
  Plus,
  Sparkles,
  ChevronRight,
  Filter,
} from 'lucide-react';
import { Line } from '../types';
import { getLineFallbackColor } from '../services/api';

export interface FavoriteItem {
  id: string; // e.g. "753", "M01", "CP_CASCAIS", "METRO_AZUL", "BARCO_CACILHAS", "MST_1"
  name: string;
  type: 'bus' | 'train' | 'metro' | 'boat' | 'tram';
  operator: string;
  color?: string;
  textColor?: string;
  subtitle?: string;
  addedAt: number;
}

const FAVORITES_STORAGE_KEY = 'cm_user_favorites';

export function getStoredFavorites(): FavoriteItem[] {
  try {
    const raw = localStorage.getItem(FAVORITES_STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) return parsed;
    }
  } catch {}
  // Itens padrão populares caso o utilizador ainda não tenha configurado
  return [
    {
      id: '753',
      name: '753 · Centro Sul ↔ Praça José Fontana',
      type: 'bus',
      operator: 'Carris',
      color: '#FFC600',
      textColor: '#000000',
      subtitle: 'Ponte 25 de Abril',
      addedAt: Date.now(),
    },
    {
      id: 'M01',
      name: 'M01 · Parede ↔ CascaiShopping',
      type: 'bus',
      operator: 'MobiCascais',
      color: '#009FE3',
      textColor: '#ffffff',
      subtitle: 'Via Estoril',
      addedAt: Date.now(),
    },
    {
      id: 'CP_CASCAIS',
      name: 'Linha de Cascais · Cais do Sodré ↔ Cascais',
      type: 'train',
      operator: 'CP',
      color: '#006633',
      textColor: '#ffffff',
      subtitle: 'Comboios Suburbanos',
      addedAt: Date.now(),
    },
    {
      id: 'BARCO_CACILHAS',
      name: 'Cais do Sodré ↔ Cacilhas',
      type: 'boat',
      operator: 'Transtejo',
      color: '#0284c7',
      textColor: '#ffffff',
      subtitle: 'Travessia Fluvial do Tejo',
      addedAt: Date.now(),
    },
  ];
}

export function saveStoredFavorites(items: FavoriteItem[]): void {
  try {
    localStorage.setItem(FAVORITES_STORAGE_KEY, JSON.stringify(items));
  } catch {}
}

export function isItemFavorite(id: string): boolean {
  const favs = getStoredFavorites();
  return favs.some((f) => f.id.toUpperCase() === id.toUpperCase());
}

export function toggleStoredFavorite(item: FavoriteItem): boolean {
  const favs = getStoredFavorites();
  const exists = favs.some((f) => f.id.toUpperCase() === item.id.toUpperCase());
  let updated: FavoriteItem[];
  if (exists) {
    updated = favs.filter((f) => f.id.toUpperCase() !== item.id.toUpperCase());
  } else {
    updated = [item, ...favs];
  }
  saveStoredFavorites(updated);
  return !exists;
}

interface FavoritesModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectLine: (lineId: string) => void;
  onSelectBoatLine?: (lineId: string) => void;
  onSelectMSTLine?: (lineId: string) => void;
  onSelectCpLine?: (lineId: 'cascais' | 'sintra' | 'azambuja' | 'sado') => void;
  onSelectMetroLine?: (lineId: 'amarela' | 'azul' | 'verde' | 'vermelha') => void;
  activeLines: string[];
  onToggleActiveLine: (lineId: string) => void;
}

export const FavoritesModal: React.FC<FavoritesModalProps> = ({
  isOpen,
  onClose,
  onSelectLine,
  onSelectBoatLine,
  onSelectMSTLine,
  onSelectCpLine,
  onSelectMetroLine,
  activeLines,
  onToggleActiveLine,
}) => {
  const [favorites, setFavorites] = useState<FavoriteItem[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<'all' | 'bus' | 'train' | 'metro' | 'boat' | 'tram'>('all');

  useEffect(() => {
    if (isOpen) {
      setFavorites(getStoredFavorites());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleRemove = (id: string) => {
    const updated = favorites.filter((f) => f.id !== id);
    setFavorites(updated);
    saveStoredFavorites(updated);
  };

  const filtered = favorites.filter((f) => {
    if (selectedCategory === 'all') return true;
    return f.type === selectedCategory;
  });

  const handleOpenItem = (item: FavoriteItem) => {
    onClose();
    if (item.type === 'boat' && onSelectBoatLine) {
      onSelectBoatLine(item.id);
    } else if (item.type === 'tram' && onSelectMSTLine) {
      onSelectMSTLine(item.id.replace('MST_', ''));
    } else if (item.type === 'train' && onSelectCpLine) {
      const lineKey = item.id.replace('CP_', '').toLowerCase() as 'cascais' | 'sintra' | 'azambuja' | 'sado';
      onSelectCpLine(lineKey);
    } else if (item.type === 'metro' && onSelectMetroLine) {
      const lineKey = item.id.replace('METRO_', '').toLowerCase() as 'amarela' | 'azul' | 'verde' | 'vermelha';
      onSelectMetroLine(lineKey);
    } else {
      onSelectLine(item.id);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="relative w-full max-w-lg bg-slate-900 border border-slate-800 rounded-3xl shadow-2xl overflow-hidden flex flex-col max-h-[85vh] text-slate-100">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-amber-400/20 text-amber-400 flex items-center justify-center border border-amber-400/30">
              <Star className="w-5 h-5 fill-amber-400" />
            </div>
            <div>
              <h2 className="text-base font-bold text-white leading-tight">Meus Transportes Favoritos</h2>
              <p className="text-xs text-slate-400 mt-0.5">
                Acesso rápido aos transportes que mais utiliza na Área Metropolitana
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors cursor-pointer"
            title="Fechar"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter Categories */}
        <div className="px-4 py-2.5 border-b border-slate-800 bg-slate-950/40 flex items-center gap-1.5 overflow-x-auto no-scrollbar">
          {[
            { id: 'all', label: 'Todos', icon: Star },
            { id: 'bus', label: 'Autocarros', icon: Bus },
            { id: 'train', label: 'Comboios (CP/Fertagus)', icon: Train },
            { id: 'boat', label: 'Barcos (Transtejo/Soflusa)', icon: Ship },
            { id: 'tram', label: 'Metro Sul do Tejo', icon: Train },
          ].map((cat) => {
            const Icon = cat.icon;
            const isSelected = selectedCategory === cat.id;
            return (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id as any)}
                className={`px-3 py-1.5 rounded-full text-xs font-semibold flex items-center gap-1.5 transition-all shrink-0 cursor-pointer ${
                  isSelected
                    ? 'bg-amber-400 text-slate-950 shadow-md shadow-amber-400/20'
                    : 'bg-slate-800/80 hover:bg-slate-800 text-slate-300'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{cat.label}</span>
              </button>
            );
          })}
        </div>

        {/* Favorites List */}
        <div className="p-4 overflow-y-auto space-y-2 flex-1">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-slate-400 space-y-2">
              <Star className="w-8 h-8 mx-auto text-slate-600" />
              <p className="text-sm font-semibold text-slate-300">Nenhum transporte nesta categoria</p>
              <p className="text-xs text-slate-500 max-w-xs mx-auto">
                Adicione linhas e transportes aos favoritos para aceder rapidamente aqui e abri-los no mapa.
              </p>
            </div>
          ) : (
            filtered.map((item) => {
              const isActive = activeLines.includes(item.id);
              const fallback = getLineFallbackColor(item.id);
              const bgColor = item.color || fallback.bg;
              const textColor = item.textColor || fallback.text;

              return (
                <div
                  key={item.id}
                  className="p-3 rounded-2xl bg-slate-800/60 hover:bg-slate-800 border border-slate-700/60 flex items-center justify-between gap-3 transition-colors"
                >
                  <div
                    onClick={() => handleOpenItem(item)}
                    className="flex items-center gap-3 min-w-0 flex-1 cursor-pointer"
                  >
                    <div
                      className="w-10 h-10 rounded-xl flex items-center justify-center font-bold font-mono text-sm shrink-0 shadow-md"
                      style={{ backgroundColor: bgColor, color: textColor }}
                    >
                      {item.type === 'boat' ? (
                        <Ship className="w-5 h-5" />
                      ) : item.type === 'train' || item.type === 'tram' ? (
                        <Train className="w-5 h-5" />
                      ) : (
                        item.id.replace('MOBI_', '')
                      )}
                    </div>

                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-white truncate">{item.name}</span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded-md bg-slate-700 text-slate-300 font-mono">
                          {item.operator}
                        </span>
                      </div>
                      {item.subtitle && (
                        <div className="text-[11px] text-slate-400 truncate mt-0.5">{item.subtitle}</div>
                      )}
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    {/* Botão de Ativar no Mapa */}
                    <button
                      onClick={() => {
                        handleOpenItem(item);
                      }}
                      className="px-2.5 py-1.5 rounded-xl bg-amber-400/20 hover:bg-amber-400/30 text-amber-300 text-xs font-semibold flex items-center gap-1 transition-colors cursor-pointer"
                      title="Ver e centrar no mapa"
                    >
                      <MapPin className="w-3.5 h-3.5" />
                      <span>Ver no mapa</span>
                    </button>

                    {/* Botão Remover */}
                    <button
                      onClick={() => handleRemove(item.id)}
                      className="p-1.5 rounded-xl text-slate-400 hover:text-rose-400 hover:bg-slate-700/60 transition-colors cursor-pointer"
                      title="Remover dos favoritos"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Footer tip */}
        <div className="p-3 border-t border-slate-800 bg-slate-950/60 text-[11px] text-slate-400 text-center flex items-center justify-center gap-2">
          <Sparkles className="w-3.5 h-3.5 text-amber-400 shrink-0" />
          <span>Os seus favoritos ficam guardados e podem ser ativados individualmente a pedido.</span>
        </div>
      </div>
    </div>
  );
};
